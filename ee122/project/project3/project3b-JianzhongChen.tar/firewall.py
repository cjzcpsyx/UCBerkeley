#!/usr/bin/env python

from main import PKT_DIR_INCOMING, PKT_DIR_OUTGOING

import socket
import struct
import time

# TODO: Feel free to import any Python standard moduless as necessary.
# (http://docs.python.org/2/library/)
# You must NOT use any 3rd-party libraries, though.

class Firewall:
    def __init__(self, config, timer, iface_int, iface_ext):
        self.timer = timer
        self.iface_int = iface_int
        self.iface_ext = iface_ext
        self.rules = [] # Load rules in a list
        self.geoipdb = [] # Load geoipdb in a dictionary
        self.expect_http = None
        self.buffer = ''
        self.expect_http2 = None
        self.buffer2 = ''
        self.http_buffer = {}
        open('http.log', 'w').close()
        self.http_methods = ['OPTIONS', 'GET', 'HEAD', 'POST', 'PUT', '/DELETE', 'TRACE', 'CONNECT']

        # TODO: Load the firewall rules (from rule_filename) here.
        rule_input = open(config['rule'],'r')
        for line in rule_input:
            if not line.startswith("%"):
                if not line == '\n':
                    if line.split()[1].lower() == "dns" or line.split()[1].lower() == 'http':
                        self.rules.append((line.split()[0].lower(),line.split()[1].lower(),line.split()[2].lower()))
                    else:
                        self.rules.append((line.split()[0].lower(),line.split()[1].lower(),line.split()[2].lower(),line.split()[3].lower()))

        # TODO: Load the GeoIP DB ('geoipdb.txt') as well.
        geoipdb_input = open('geoipdb.txt','r')
        for line in geoipdb_input:
            if not line == '\n':
                self.geoipdb.append((self.string_to_ip(line.split()[0].lower()), self.string_to_ip(line.split()[1].lower()),line.split()[2].lower()))
        
        # TODO: Also do some initialization if needed.
        self.timer.schedule(time.time() + 10.0)

    def handle_timer(self):
        # TODO: For the timer feature, refer to bypass.py
        print '%s: I am still alive' % time.ctime()
        self.timer.schedule(time.time() + 10.0)

    # @pkt_dir: either PKT_DIR_INCOMING or PKT_DIR_OUTGOING
    # @pkt: the actual data of the IPv4 packet (including IP header)
    def handle_packet(self, pkt_dir, pkt):
        # TODO: Your main firewall code will be here.
        # print '===== new packet ====='
        protocal_id = struct.unpack('!B', pkt[9])[0]
        pass_pkt, deny_pkt = True, False
        response_pkt = ''
        
        src_ip = pkt[12:16]
        dst_ip = pkt[16:20]
        ipid, = struct.unpack('!H', pkt[4:6])    # IP identifier (big endian)
        
        if pkt_dir == PKT_DIR_INCOMING:
            dir_str = 'incoming'
        else:
            dir_str = 'outgoing'

        # print '%s len=%4dB, IPID=%5d  %15s -> %15s' % (dir_str, len(pkt), ipid,
        #         socket.inet_ntoa(src_ip), socket.inet_ntoa(dst_ip))


        if protocal_id == 1: # ICMP
            # print 'handle ICMP'
            pass_pkt = self.check_icmp(pkt_dir, pkt)
        elif protocal_id == 6: # TCP
            # print 'handle TCP'
            pass_pkt, deny_pkt, response_pkt = self.check_tcp(pkt_dir, pkt)
        elif protocal_id == 17: # UDP
            # print 'handle UDP'
            pass_pkt, deny_pkt, response_pkt = self.check_udp(pkt_dir, pkt)

        if pass_pkt:
            # print 'pass'
            if pkt_dir == PKT_DIR_INCOMING:
                self.iface_int.send_ip_packet(pkt)
            elif pkt_dir == PKT_DIR_OUTGOING:
                self.iface_ext.send_ip_packet(pkt)
        elif deny_pkt:
            # print 'deny'
            if pkt_dir == PKT_DIR_INCOMING:
                self.iface_ext.send_ip_packet(response_pkt)
                # print 'outgoing response_pkt, IPID=%5d %15s->%15s' % (struct.unpack('!H', response_pkt[4:6])[0], socket.inet_ntoa(response_pkt[12:16]), socket.inet_ntoa(response_pkt[16:20]))
            elif pkt_dir == PKT_DIR_OUTGOING:
                self.iface_int.send_ip_packet(response_pkt)
                # print 'incoming response_pkt, IPID=%5d %15s->%15s' % (struct.unpack('!H', response_pkt[4:6])[0], socket.inet_ntoa(response_pkt[12:16]), socket.inet_ntoa(response_pkt[16:20]))
        # else:
        #     print 'drop'
    # TODO: You can add more methods as you want.

    # @packet: the packet received to check
    def check_icmp(self, pkt_dir, pkt):
        ihl = struct.unpack('!B', pkt[0])[0] & 15
        if ihl < 5:
            return False
        
        type_num = struct.unpack('!B', pkt[ihl*4])[0] # Type number as an int
        if pkt_dir == PKT_DIR_INCOMING:
            ip = socket.inet_ntoa(pkt[12:16]) # ip as standard dotted string
        elif pkt_dir == PKT_DIR_OUTGOING:
            ip = socket.inet_ntoa(pkt[16:20]) # ip as standard dotted string

        pass_packet = True
        for icmp_rule in self.rules:
            if icmp_rule[1] == 'icmp': # an icmp rule
                if self.ip_match(ip, icmp_rule[2]) and self.port_match(type_num, icmp_rule[3]): # if the packet info matches the rule
                    pass_packet = (icmp_rule[0] == 'pass')
        return pass_packet


    def check_udp(self, pkt_dir, pkt):
        ihl = struct.unpack('!B', pkt[0])[0] & 15
        if ihl < 5:
            return False, False, ''
        
        if pkt_dir == PKT_DIR_INCOMING:
            ip = socket.inet_ntoa(pkt[12:16]) # ip as standard dotted string
            port = struct.unpack('!H', pkt[ihl*4:ihl*4+2])[0] # port number as an int
        elif pkt_dir == PKT_DIR_OUTGOING:
            ip = socket.inet_ntoa(pkt[16:20]) # ip as standard dotted string
            port = struct.unpack('!H', pkt[ihl*4+2:ihl*4+4])[0] # port number as an int

        pass_packet, deny_packet, response = True, False,''
        for udp_rule in self.rules:
            if udp_rule[1] == 'udp': # a udp rule
                if self.ip_match(ip, udp_rule[2]) and self.port_match(port, udp_rule[3]): # if the packet info matches the rule
                    pass_packet = (udp_rule[0] == 'pass')
            if udp_rule[1] == 'dns': # a dns rule
                # print 'udp rule:%s' % (udp_rule,)
                if port == 53: # port number should be 53
                    if struct.unpack('!H', pkt[ihl*4+8+4:ihl*4+8+6])[0] == 1: # QCOUNT should be 1
                        qname, qname_length = self.get_qname(pkt[ihl*4+8+12:])
                        # print qname, qname_length
                        if not (qname == False): # if not failed to decode
                            qtype = struct.unpack('!H', pkt[ihl*4+8+12+qname_length:ihl*4+8+12+qname_length+2])[0] # get qtype of the DNS request
                            qclass = struct.unpack('!H', pkt[ihl*4+8+12+qname_length+2:ihl*4+8+12+qname_length+4])[0] # get the qclass of the DNS request
                            # print qtype,qclass
                            if qtype == 1 or qtype == 28: # QTYPE should be 1 or 28
                                if qclass == 1: # QCLASS should be 1
                                    if self.dns_match(qname, udp_rule[2]):
                                        if udp_rule[0] == 'pass':
                                            pass_packet, deny_packet, response = True, False, ''
                                        elif udp_rule[0] == 'drop':
                                            pass_packet, deny_packet, response = False, False, ''
                                        elif udp_rule[0] == 'deny':
                                            pass_packet, deny_packet, response = False, True, self.generate_dns_response(pkt, qname_length)
        return pass_packet, deny_packet, response

    def check_tcp(self, pkt_dir, pkt):
        ihl = struct.unpack('!B', pkt[0])[0] & 15
        if ihl < 5:
            # print 'ihl less than 5 drop'
            return False, False, ''

        if pkt_dir == PKT_DIR_INCOMING:
            ip = socket.inet_ntoa(pkt[12:16]) # ip as standard dotted string
            port = struct.unpack('!H', pkt[ihl*4:ihl*4+2])[0] # port number as an int
        elif pkt_dir == PKT_DIR_OUTGOING:
            ip = socket.inet_ntoa(pkt[16:20]) # ip as standard dotted string
            port = struct.unpack('!H', pkt[ihl*4+2:ihl*4+4])[0] # port number as an int

        pass_packet, deny_packet, response = True, False, ''
        for tcp_rule in self.rules:
            if tcp_rule[1] == 'tcp': # a tcp rule
                if self.ip_match(ip, tcp_rule[2]) and self.port_match(port, tcp_rule[3]): # if the packet info matches the rule
                    if tcp_rule[0] == 'pass':
                        pass_packet, deny_packet, response = True, False, ''
                    elif tcp_rule[0] == 'drop':
                        pass_packet, deny_packet, response = False, False, ''
                    elif tcp_rule[0] == 'deny':
                        pass_packet, deny_packet, response = False, True, self.generate_rst(pkt)
        if port == 80:
            if pass_packet:
                payload = pkt[ihl*4+(struct.unpack('!B',pkt[ihl*4+12:ihl*4+13])[0]>>4)*4:]
                if not payload == '':
                    seq = struct.unpack('!I', pkt[ihl*4+4:ihl*4+8])[0]
                    ack = struct.unpack('!I', pkt[ihl*4+8: ihl*4+12])[0]
                    if pkt_dir == PKT_DIR_OUTGOING:
                        # print '=====request====='
                        # print 'buffer:'
                        # print self.buffer
                        # print '\nexpect_http'
                        # print self.expect_http
                        # print '\npayload:'
                        # print payload
                        if self.expect_http == None:
                            try:
                                host_name = self.get_host(payload, ip)
                                method = payload.split(' ')[0]
                                path = payload.split(' ')[1]
                                version = payload.split('\r\n')[0].split(' ')[2]
                                self.http_buffer[ack] = (host_name, method, path, version)
                            except IndexError:
                                if ' ' in payload and payload.split(' ')[0] in self.http_methods:
                                    self.buffer = payload
                                    self.expect_http = (seq, (seq+len(payload)) & 0xFFFFFFFF)
                        else:
                            if seq == self.expect_http[1]:
                                try:
                                    self.buffer += payload
                                    host_name = self.get_host(self.buffer, ip)
                                    method = self.buffer.split(' ')[0]
                                    path = self.buffer.split(' ')[1]
                                    version = self.buffer.split('\r\n')[0].split(' ')[2]
                                    self.http_buffer[ack] = (host_name, method, path, version)
                                    self.buffer = ''
                                    self.expect_http = None
                                except IndexError:
                                    self.buffer += payload
                                    self.expect_http = (self.expect_http[0], (seq+len(payload)) & 0xFFFFFFFF)
       
                            else:
                                # print self.buffer
                                # print 'drop out of order request'
                                # pass_packet, deny_packet, response = False, False, ''
                                pass
                    elif pkt_dir == PKT_DIR_INCOMING:
                        # print '=====response====='
                        # print payload
                        if self.expect_http2 == None:
                            try:
                                if seq in self.http_buffer.keys():
                                    status_code = payload.split(' ')[1]
                                    object_size = self.get_object_size(payload)
                                    self.check_log(self.http_buffer[seq], status_code, object_size, payload.split('\r\n')[0].split(' ')[1]+payload.split('\r\n')[0].split(' ')[2])
                                    del self.http_buffer[seq]
                                else:
                                    pass
                            except IndexError:
                                if ' ' in payload and payload.startswith('HTTP'):
                                    if seq in self.http_buffer.keys():
                                        self.buffer2 = payload
                                        self.expect_http2 = (seq, (seq+len(payload)) & 0xFFFFFFFF)
                                    else:
                                        pass
                        else:
                            if seq == self.expect_http2[1]:
                                try:
                                    self.buffer2 += payload
                                    status_code = self.buffer2.split(' ')[1]
                                    object_size = self.get_object_size(self.buffer2)
                                    self.check_log(self.http_buffer[self.expect_http2[0]], status_code, object_size)
                                    del self.http_buffer[self.expect_http2[0]]
                                except IndexError:
                                    self.buffer2 += payload
                                    self.expect_http2 = (self.expect_http2[0], (seq+len(payload)) & 0xFFFFFFFF)
                            else:
                                pass

        return pass_packet, deny_packet, response

    # @pkt_ip: ip address of packet as a dotted string
    # @rule_ip: ip adddress of rule as a dotted string
    def ip_match(self, pkt_ip, rule_ip):
        # print 'matching IP: pkt-%s, rule-%s' % (pkt_ip, rule_ip)
        if rule_ip == 'any': # rule_ip is 'any'
            return True
        elif len(rule_ip) == 2: # rule_ip is a country code
            return self.search_countrycode(pkt_ip) == rule_ip
        elif len(rule_ip.split('/')) == 1: # rule_ip is a single ip address
            return pkt_ip == rule_ip
        else: # rule_ip has a prefix
            prefix = int(rule_ip.split('/')[1])
            temp_ip = rule_ip.split('/')[0]
            return self.string_to_ip(pkt_ip) >> (32 - prefix) << (32 - prefix) == self.string_to_ip(temp_ip) >> (32 - prefix) << (32 - prefix)

    # @pkt_port: port number or type number as an int
    # @rule_port: port number or type number as a string
    def port_match(self, pkt_port, rule_port):
        # print 'matching port: pkt-%s, rule-%s' % (pkt_port, rule_port)
        if rule_port == 'any': # rule_port is 'any'
            return True
        elif len(rule_port.split('-')) == 1: # rule_port is a single value
            return pkt_port == int(rule_port)
        else: # rule_port is a range
            return int(rule_port.split('-')[0]) <= pkt_port <= int(rule_port.split('-')[1])

    # @ip_string: ip as a standard dotted string
    # return an int that represent the ip_string
    def string_to_ip(self, ip_string):
        temp = ip_string.split('.')
        return int(temp[0]) << 24 | int(temp[1]) << 16 | int(temp[2]) << 8 | int(temp[3])

    # find the qname and the length of the qname of a DNS request
    def get_qname(self, rest_file):
        qname = ''
        qname_length = 0
        while not (struct.unpack('!B', rest_file[0])[0] == 0 or rest_file[0] == ''): # while not length byte==0 or end of file
            qname_length = qname_length + struct.unpack('!B', rest_file[0])[0] + 1# length of qname add length byte
            qname = qname + rest_file[1:struct.unpack('!B', rest_file[0])[0] + 1] + '.' # qname append bytes of the length
            rest_file = rest_file[struct.unpack('!B', rest_file[0])[0] + 1:] # update rest_file
        if rest_file[0] == '': # if stop with end of file
            return (False, False)
        else: # end normally with length byte==0
            return (qname, qname_length + 1)

    def dns_match(self, qname_address, rule_address):
        # print rule_address
        if rule_address.startswith('*'):
            # print qname_address.split('.')[len(qname_address.split('.'))-len(rule_address.split('.')):len(qname_address.split('.'))-1]
            # print rule_address.split('.')[1:]
            return qname_address.split('.')[len(qname_address.split('.'))-len(rule_address.split('.')):len(qname_address.split('.'))-1] == rule_address.split('.')[1:]
        else:
            # print qname_address.split('.')[:len(qname_address.split('.'))-1]
            # print rule_address.split('.')
            return qname_address.split('.')[:len(qname_address.split('.'))-1] == rule_address.split('.')

    def search_countrycode(self, pkt_ip):
        prev = 0
        next = len(self.geoipdb) - 1
        pkt_ip_num = self.string_to_ip(pkt_ip)
        while not prev == next - 1:
            if pkt_ip_num < self.geoipdb[prev + (next-prev)/2][0]:
                if (next-prev)%2 ==1:
                    next = next - (next-prev)/2 - 1
                else:
                    next = next - (next-prev)/2
            else:
                prev = prev + (next-prev)/2
        return self.geoipdb[prev][2]


# TODO: You may want to add more classes/functions as well.

# partB fuctions
    
    def generate_rst(self, pkt):
        new = ''
        ihl = struct.unpack('!B', pkt[0])[0] & 15

        check_sum_ip = (((4<<4)+5)<<8) + 40 + 0 + 0 + ((struct.unpack('!B', pkt[8:9])[0]<<8)+6) + sum(struct.unpack('!4H', pkt[12:20]))

        check_sum_ip = (check_sum_ip>>16) + (check_sum_ip & 0xFFFF)
        check_sum_ip += (check_sum_ip>>16)
        check_sum_ip = ~check_sum_ip
        check_sum_ip = check_sum_ip & 0xFFFF

        new += struct.pack('!6H2I', ((4<<4)+5)<<8, 40, 0, 0, (struct.unpack('!B', pkt[8:9])[0]<<8)+6, check_sum_ip, struct.unpack('!I', pkt[16:20])[0], struct.unpack('!I', pkt[12:16])[0])

        check_sum_tcp = sum(struct.unpack('!2H', pkt[ihl*4:ihl*4+4])) + 0 + 0 + (sum(struct.unpack('!2H', pkt[ihl*4+4:ihl*4+8])) + 1) + (((5<<4)<<8) + 20) + 0 + 0 + sum(struct.unpack('!4H', pkt[12:20])) + ((0<< 4) + 6) + 20
        
        check_sum_tcp = (check_sum_tcp>>16) + (check_sum_tcp & 0xFFFF)
        check_sum_tcp += (check_sum_tcp>>16)
        check_sum_tcp = ~check_sum_tcp
        check_sum_tcp = check_sum_tcp & 0xFFFF

        new += struct.pack('!2H2I4H', struct.unpack('!H', pkt[ihl*4+2:ihl*4+4])[0], struct.unpack('!H', pkt[ihl*4:ihl*4+2])[0], 0, struct.unpack('!I', pkt[ihl*4+4:ihl*4+8])[0] + 1, (((5<<4)<<8) + 20), 0, check_sum_tcp, 0)
        
        return new

    def generate_dns_response(self, pkt, qname_length):
        new = ''
        ihl = struct.unpack('!B', pkt[0])[0] & 15
        dns_total_length = 12 + qname_length + 2 + 2 + 2 + 2 + 2 + 4 + 2 + 4

        check_sum_ip = (((4<<4)+5)<<8) + (20 + 8 + dns_total_length) + 0 + 0 + ((struct.unpack('!B', pkt[8:9])[0]<<8)+17) + sum(struct.unpack('!4H', pkt[12:20]))

        check_sum_ip = (check_sum_ip>>16) + (check_sum_ip & 0xFFFF)
        check_sum_ip += (check_sum_ip>>16)
        check_sum_ip = ~check_sum_ip
        check_sum_ip = check_sum_ip & 0xFFFF

        new += struct.pack('!6H2I', ((4<<4)+5)<<8, (20 + 8 + dns_total_length), 0, 0, (struct.unpack('!B', pkt[8:9])[0]<<8)+17, check_sum_ip, struct.unpack('!I', pkt[16:20])[0], struct.unpack('!I', pkt[12:16])[0])

        check_sum_udp = 0

        check_sum_ip = (check_sum_ip>>16) + (check_sum_ip & 0xFFFF)
        check_sum_ip += (check_sum_ip>>16)
        check_sum_ip = ~check_sum_ip
        check_sum_ip = check_sum_ip & 0xFFFF

        new += struct.pack('!4H', struct.unpack('!H', pkt[ihl*4+2:ihl*4+4])[0], struct.unpack('!H', pkt[ihl*4:ihl*4+2])[0], (8 + dns_total_length), check_sum_udp)

        new = new + pkt[ihl*4+8:ihl*4+8+2] + struct.pack('!5H', (1<<15)+struct.unpack('!H', pkt[ihl*4+8+2:ihl*4+8+4])[0], 1, 1, 0, 0) + pkt[ihl*4+8+12:ihl*4+8+12+qname_length+2+2] + struct.pack('!3HIH4B', 49164, 1, 1, 1, 4, 169, 229, 49, 109)

        return new

    def get_host(self, payload, ext_ip):
        for lines in payload.split('\r\n'):
            if lines.startswith('Host:'):
                return lines.split(' ')[1]
        return ext_ip

    def get_object_size(self, payload):
        for lines in payload.split('\r\n'):
            if lines.startswith('Content-Length:') or lines.startswith('content-length'):
                try:
                    return lines.split(' ')[1]
                except IndexError:
                    return lines.split(':')[1]
        return '-1'

    def check_log(self, request, status_code, object_size, bw1):
        log_it = False
        for http_rule in self.rules:
            if http_rule[1] == 'http' and http_rule[0] == 'log':
                if self.host_match(request[0], http_rule[2]):
                    log_it = True
        if log_it:
            f = open('http.log', 'a')
            f.write(request[0]+' '+request[1]+' '+request[2]+' '+request[3]+' '+status_code+' '+object_size+'\n')
            f.flush

    def host_match(self, pkt_host, rule_host):
        if rule_host.startswith('*'):
            if rule_host == '*':
                return True
            else:
                return pkt_host.split('.')[len(pkt_host.split('.'))-len(rule_host.split('.'))+1:] == rule_host.split('.')[1:]
        else:
            return pkt_host == rule_host