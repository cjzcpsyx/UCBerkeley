Name: Jianzhong Chen
Login: ee122-bv

I have attached files for ec1.

Very usefull project. Full of fun. After doing this project, I learnt alot about the structure of ip packets.
The staffs are doing great jobs this semester!!!!!!!!!!!
The same comments as part a, BECAUSE these tow parts together teach me alot :)
Good project.