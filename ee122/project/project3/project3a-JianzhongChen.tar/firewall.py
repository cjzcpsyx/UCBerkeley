#!/usr/bin/env python

from main import PKT_DIR_INCOMING, PKT_DIR_OUTGOING

import socket
import struct
import time

# TODO: Feel free to import any Python standard moduless as necessary.
# (http://docs.python.org/2/library/)
# You must NOT use any 3rd-party libraries, though.

class Firewall:
    def __init__(self, config, timer, iface_int, iface_ext):
        self.timer = timer
        self.iface_int = iface_int
        self.iface_ext = iface_ext
        self.rules = [] # Load rules in a list
        self.geoipdb = [] # Load geoipdb in a dictionary

        # TODO: Load the firewall rules (from rule_filename) here.
        rule_input = open(config['rule'],'r')
        for line in rule_input:
            if not line.startswith("%"):
                if not line == '\n':
                    if line.split()[1].lower() == "dns":
                        self.rules.append((line.split()[0].lower(),line.split()[1].lower(),line.split()[2].lower()))
                    else:
                        self.rules.append((line.split()[0].lower(),line.split()[1].lower(),line.split()[2].lower(),line.split()[3].lower()))

        # TODO: Load the GeoIP DB ('geoipdb.txt') as well.
        geoipdb_input = open('geoipdb.txt','r')
        for line in geoipdb_input:
            if not line == '\n':
                self.geoipdb.append((self.string_to_ip(line.split()[0].lower()), self.string_to_ip(line.split()[1].lower()),line.split()[2].lower()))
        
        # TODO: Also do some initialization if needed.
        self.timer.schedule(time.time() + 10.0)

    def handle_timer(self):
        # TODO: For the timer feature, refer to bypass.py
        print '%s: I am still alive' % time.ctime()
        self.timer.schedule(time.time() + 10.0)

    # @pkt_dir: either PKT_DIR_INCOMING or PKT_DIR_OUTGOING
    # @pkt: the actual data of the IPv4 packet (including IP header)
    def handle_packet(self, pkt_dir, pkt):
        # TODO: Your main firewall code will be here.
        protocal_id = struct.unpack('!B', pkt[9])[0]
        pass_pkt = True
        
        src_ip = pkt[12:16]
        dst_ip = pkt[16:20]
        ipid, = struct.unpack('!H', pkt[4:6])    # IP identifier (big endian)
        
        if pkt_dir == PKT_DIR_INCOMING:
            dir_str = 'incoming'
        else:
            dir_str = 'outgoing'

        print '%s len=%4dB, IPID=%5d  %15s -> %15s' % (dir_str, len(pkt), ipid,
                socket.inet_ntoa(src_ip), socket.inet_ntoa(dst_ip))


        if protocal_id == 1: # ICMP
            print 'handle ICMP'
            pass_pkt = self.check_icmp(pkt_dir, pkt)
        elif protocal_id == 6: # TCP
            print 'handle TCP'
            pass_pkt = self.check_tcp(pkt_dir, pkt)
        elif protocal_id == 17: # UDP
            print 'handle UDP'
            pass_pkt = self.check_udp(pkt_dir, pkt)
        
        if pass_pkt:
            if pkt_dir == PKT_DIR_INCOMING:
                self.iface_int.send_ip_packet(pkt)
            elif pkt_dir == PKT_DIR_OUTGOING:
                self.iface_ext.send_ip_packet(pkt)
    # TODO: You can add more methods as you want.

    # @packet: the packet received to check
    def check_icmp(self, pkt_dir, pkt):
        ihl = struct.unpack('!B', pkt[0])[0] & 15
        if ihl < 5:
            return False
        
        type_num = struct.unpack('!B', pkt[ihl*4])[0] # Type number as an int
        if pkt_dir == PKT_DIR_INCOMING:
            ip = socket.inet_ntoa(pkt[12:16]) # ip as standard dotted string
        elif pkt_dir == PKT_DIR_OUTGOING:
            ip = socket.inet_ntoa(pkt[16:20]) # ip as standard dotted string

        pass_packet = True
        for icmp_rule in self.rules:
            if icmp_rule[1] == 'icmp': # an icmp rule
                if self.ip_match(ip, icmp_rule[2]) and self.port_match(type_num, icmp_rule[3]): # if the packet info matches the rule
                    pass_packet = (icmp_rule[0] == 'pass')
        return pass_packet


    def check_udp(self, pkt_dir, pkt):
        ihl = struct.unpack('!B', pkt[0])[0] & 15
        if ihl < 5:
            return False
        
        if pkt_dir == PKT_DIR_INCOMING:
            ip = socket.inet_ntoa(pkt[12:16]) # ip as standard dotted string
            port = struct.unpack('!H', pkt[ihl*4:ihl*4+2])[0] # port number as an int
        elif pkt_dir == PKT_DIR_OUTGOING:
            ip = socket.inet_ntoa(pkt[16:20]) # ip as standard dotted string
            port = struct.unpack('!H', pkt[ihl*4+2:ihl*4+4])[0] # port number as an int

        pass_packet = True
        for udp_rule in self.rules:
            if udp_rule[1] == 'udp': # a udp rule
                if self.ip_match(ip, udp_rule[2]) and self.port_match(port, udp_rule[3]): # if the packet info matches the rule
                    pass_packet = (udp_rule[0] == 'pass')
            if udp_rule[1] == 'dns': # a dns rule
                if port == 53: # port number should be 53
                    if struct.unpack('!H', pkt[ihl*4+8+4:ihl*4+8+6])[0] == 1: # QCOUNT should be 1
                        qname, qname_length = self.get_qname(pkt[ihl*4+8+12:])
                        if not qname: # if not failed to decode
                            qtype = struct.unpack('!H', pkt[ihl*4+8+12+qname_length:ihl*4+8+12+qname_length+2])[0] # get qtype of the DNS request
                            qclass = struct.unpack(pkt[ihl*4+8+12+qname_length+2:ihl*4+8+12+qname_length+4])[0] # get the qclass of the DNS request
                            if qtype == 1 or qtype == 28: # QTYPE should be 1 or 28
                                if qclass == 1: # QCLASS should be 1
                                    if self.dns_match(qname, udp_rule[2]):
                                        pass_packet = (udp_rule[0] == 'pass')
        return pass_packet




    def check_tcp(self, pkt_dir, pkt):
        ihl = struct.unpack('!B', pkt[0])[0] & 15
        if ihl < 5:
            print 'ihl less than 5 drop'
            return False

        if pkt_dir == PKT_DIR_INCOMING:
            ip = socket.inet_ntoa(pkt[12:16]) # ip as standard dotted string
            port = struct.unpack('!H', pkt[ihl*4:ihl*4+2])[0] # port number as an int
        elif pkt_dir == PKT_DIR_OUTGOING:
            ip = socket.inet_ntoa(pkt[16:20]) # ip as standard dotted string
            port = struct.unpack('!H', pkt[ihl*4+2:ihl*4+4])[0] # port number as an int

        pass_packet = True
        for tcp_rule in self.rules:
            if tcp_rule[1] == 'tcp': # a tcp rule
                if self.ip_match(ip, tcp_rule[2]) and self.port_match(port, tcp_rule[3]): # if the packet info matches the rule
                    pass_packet = (tcp_rule[0] == 'pass')
        return pass_packet

    # @pkt_ip: ip address of packet as a dotted string
    # @rule_ip: ip adddress of rule as a dotted string
    def ip_match(self, pkt_ip, rule_ip):
        if rule_ip == 'any': # rule_ip is 'any'
            return True
        elif len(rule_ip) == 2: # rule_ip is a country code
            return self.search_countrycode(pkt_ip) == rule_ip
        elif len(rule_ip.split('/')) == 1: # rule_ip is a single ip address
            return pkt_ip == rule_ip
        else: # rule_ip has a prefix
            prefix = int(rule_ip.split('/')[1])
            temp_ip = rule_ip.split('/')[0]
            return self.string_to_ip(pkt_ip) >> (32 - prefix) << (32 - prefix) == self.string_to_ip(temp_ip) >> (32 - prefix) << (32 - prefix)

    # @pkt_port: port number or type number as an int
    # @rule_port: port number or type number as a string
    def port_match(self, pkt_port, rule_port):
        if rule_port == 'any': # rule_port is 'any'
            return True
        elif len(rule_port.split('-')) == 1: # rule_port is a single value
            return pkt_port == int(rule_port)
        else: # rule_port is a range
            return int(rule_port.split('-')[0]) <= pkt_port <= int(rule_port.split('-')[1])

    # @ip_string: ip as a standard dotted string
    # return an int that represent the ip_string
    def string_to_ip(self, ip_string):
        temp = ip_string.split('.')
        return int(temp[0]) << 24 | int(temp[1]) << 16 | int(temp[2]) << 8 | int(temp[3])

    # find the qname and the length of the qname of a DNS request
    def get_qname(self, rest_file):
        qname = ''
        qname_length = 0
        while not (struct.unpack('!B', rest_file[0])[0] == 0 or rest_file[0] == ''): # while not length byte==0 or end of file
            qname_length = qname_length + struct.unpack('!B', rest_file[0])[0] + 1# length of qname add length byte
            qname = qname + rest_file[1:struct.unpack('!B', rest_file[0])[0] + 1] + '.' # qname append bytes of the length
            rest_file = rest_file[struct.unpack('!B', rest_file[0])[0] + 1:] # update rest_file
        if rest_file[0] == '': # if stop with end of file
            return (False, False)
        else: # end normally with length byte==0
            return (qname, qname_length)

    def dns_match(self, qname_address, rule_address):
        if rules.startswith('*'):
            return qname_address.split('.')[len(qname_address.split('.'))-len(rule_address.split('.')):len(qname_address.split('.'))-1] == rule_address.split('.')[1:]
        else:
            return qname_address.split('.')[:len(qname_address.split('.'))-1] == rule_address.split('.')

    def search_countrycode(self, pkt_ip):
        prev = 0
        next = len(self.geoipdb) - 1
        pkt_ip_num = self.string_to_ip(pkt_ip)
        while not prev == next - 1:
            if pkt_ip_num < self.geoipdb[prev + (next-prev)/2][0]:
                if (next-prev)%2 ==1:
                    next = next - (next-prev)/2 - 1
                else:
                    next = next - (next-prev)/2
            else:
                prev = prev + (next-prev)/2
        return self.geoipdb[prev][2]


# TODO: You may want to add more classes/functions as well.
