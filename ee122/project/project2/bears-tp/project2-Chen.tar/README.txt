Name: Jianzhong Chen
Login: ee122-bv

How challenging: 5
How long: 15 hours