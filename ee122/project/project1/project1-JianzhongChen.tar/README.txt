1. Jianzhong Chen

2. Implementing posioned reverse was a chalenge at first, then the bigiest challenge is to figure out how to solve those seemed endless mistakes. Also if two path have same length, how to update the distance vector and determain how to update pathes like this is a great challenge.

3. I notice that when the update progress comes to the end. The last few packets actually contain only a few updates, so dilivering all avalible pathes again may increase the size of packet and make the transmissions less efficient. So if there is another special pecket called withdraw packet or add element packet, we can decrease the size of each packet we deliver and save more bandwidth.

4. I did not plan to do the extra-credit. But the first extra-credit may still works woth my current implementation.